<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class dr_hourly extends Model
{
    protected $table = "dr_hourly";
    use HasFactory;
}
