<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Dr_audit extends Model
{
    protected $table = "dr_audit";
    use HasFactory;
}
