<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class dr_branch extends Model
{
    protected $table = 'dr_branch';
    use HasFactory;
}
