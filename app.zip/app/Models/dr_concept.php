<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class dr_concept extends Model
{
    protected $table =  'dr_concept';
    use HasFactory;
}
