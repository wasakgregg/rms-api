<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class dr_payment_details extends Model
{
    protected $table = 'dr_payment_details';
    use HasFactory;
}
